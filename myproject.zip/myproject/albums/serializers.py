from rest_framework import serializers
from .models import Customer, Credit, Deposit

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ('id', 'full_name', 'email', 'phone', 'address')  # Уберите 'user' отсюда
        # fields = '__all__'  # Если используете это, закомментируйте и укажите поля явно

    def create(self, validated_data):
        # Автоматически назначаем текущего пользователя
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)

class CreditSerializer(serializers.ModelSerializer):
    class Meta:
        model = Credit
        fields = '__all__'

class DepositSerializer(serializers.ModelSerializer):
    class Meta:
        model = Deposit
        fields = '__all__'