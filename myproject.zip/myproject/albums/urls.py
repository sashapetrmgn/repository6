'''from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
]'''

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'customers', views.CustomerViewSet)
router.register(r'credits', views.CreditViewSet)
router.register(r'deposits', views.DepositViewSet)

urlpatterns = [
    path('', include(router.urls)),
]