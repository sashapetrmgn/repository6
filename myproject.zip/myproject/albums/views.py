'''import os
import json
import uuid
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import default_storage
from django.http import HttpResponse
from .forms import AlbumForm, UploadFileForm, ALBUM_SCHEMA
import jsonschema
from django.contrib import messages  


ALBUMS_DIR = os.path.join(settings.MEDIA_ROOT, 'albums')

def ensure_albums_dir():
    if not os.path.exists(ALBUMS_DIR):
        os.makedirs(ALBUMS_DIR)

def index(request):
    ensure_albums_dir()
    albums_data = []
    json_files = [f for f in os.listdir(ALBUMS_DIR) if f.endswith('.json')]
    
    if not json_files:
        message = "На сервере нет файлов с данными альбомов."
    else:
        message = None
        for file_name in json_files:
            file_path = os.path.join(ALBUMS_DIR, file_name)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    albums_data.append({
                        'file_name': file_name,
                        'data': data
                    })
            except (json.JSONDecodeError, IOError):
                
                continue
    
    return render(request, 'index.html', {
        'albums': albums_data,
        'message': message
    })

def add_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            album_data = form.to_json()
            
            file_name = f"{uuid.uuid4()}.json"
            file_path = os.path.join(ALBUMS_DIR, file_name)
            ensure_albums_dir()
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(album_data, f, ensure_ascii=False, indent=4)
            return redirect('index')
    else:
        form = AlbumForm()
    return render(request, 'add_album.html', {'form': form})


def upload_file(request):
    print(f"Request method: {request.method}")  
    print(f"Request.FILES: {request.FILES}")    
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        print(f"Form is valid: {form.is_valid()}")  
        print(f"Form errors: {form.errors}")       
        if form.is_valid():
            uploaded_file = form.cleaned_data['file']
            print(f"Uploaded file: {uploaded_file}")  
            
            
            if uploaded_file is None:
                messages.error(request, "Файл не выбран или не загружен.")
                return render(request, 'upload.html', {'form': form})
            
            
            max_size = 10 * 1024 * 1024  
            try:
                print(f"File size: {uploaded_file.size}")  
                if uploaded_file.size > max_size:
                    messages.error(request, f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
                    return render(request, 'upload.html', {'form': form})
            except AttributeError:
                messages.error(request, "Ошибка при проверке размера файла.")
                return render(request, 'upload.html', {'form': form})
            
            try:
                content = uploaded_file.read().decode('utf-8')
                print(f"Content length: {len(content)}")  
                data = json.loads(content)  
                jsonschema.validate(instance=data, schema=ALBUM_SCHEMA) 
                
                ensure_albums_dir()
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)  
                print(f"File saved to: {file_path}")  
                messages.success(request, "Файл успешно загружен и валидирован.")
                return redirect('index')  
            except (json.JSONDecodeError, jsonschema.ValidationError) as e:
                messages.error(request, f"Неверный формат JSON или данные не соответствуют схеме: {e}")
                return render(request, 'upload.html', {'form': form})
            except UnicodeDecodeError:
                messages.error(request, "Файл не является корректным текстовым файлом (UTF-8).")
                return render(request, 'upload.html', {'form': form})
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})


    

def delete_album(request, file_name):
    if request.method == 'POST':
        
        safe_file_name = os.path.basename(file_name)  
        if not safe_file_name.endswith('.json'):
            messages.error(request, "Неверный файл для удаления.")
            return redirect('index')
        
        file_path = os.path.join(ALBUMS_DIR, safe_file_name)
        print(f"Попытка удалить файл: {file_path}")  
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"Файл {safe_file_name} удалён успешно.")  
                messages.success(request, f"Альбом '{safe_file_name}' успешно удалён.")
            except OSError as e:
                print(f"Ошибка удаления: {e}")  
                messages.error(request, f"Ошибка при удалении файла: {e}")
        else:
            print(f"Файл {safe_file_name} не найден.")  
            messages.warning(request, f"Файл '{safe_file_name}' не найден.")
        return redirect('index')
    else:
        
        return redirect('index')
'''

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Customer, Credit, Deposit
from .serializers import CustomerSerializer, CreditSerializer, DepositSerializer

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [IsAuthenticated]

class CreditViewSet(viewsets.ModelViewSet):
    queryset = Credit.objects.all()
    serializer_class = CreditSerializer
    permission_classes = [IsAuthenticated]

class DepositViewSet(viewsets.ModelViewSet):
    queryset = Deposit.objects.all()
    serializer_class = DepositSerializer
    permission_classes = [IsAuthenticated]